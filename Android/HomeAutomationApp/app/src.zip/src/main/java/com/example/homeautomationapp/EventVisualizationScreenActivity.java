package com.example.homeautomationapp;

import android.app.Activity;
import android.os.Bundle;

public class EventVisualizationScreenActivity extends Activity {

		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_event_visualization_screen);
			
		}
		
	}